<?php
namespace Adm\NewsletterAdminNotify\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Mail\Template\TransportBuilder;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Translate\Inline\StateInterface;

class SubscriberSaveAfter implements ObserverInterface
{
    protected $transportBuilder;
    protected $storeManager;
    protected $inlineTranslation;

    public function __construct(
        TransportBuilder $transportBuilder,
        StoreManagerInterface $storeManager,
        StateInterface $inlineTranslation
    ) {
        $this->transportBuilder = $transportBuilder;
        $this->storeManager = $storeManager;
        $this->inlineTranslation = $inlineTranslation;
    }

    public function execute(Observer $observer)
    {
        $subscriber = $observer->getEvent()->getSubscriber();
        // Check if subscriber status is subscribed
        if ($subscriber->getSubscriberStatus() == \Magento\Newsletter\Model\Subscriber::STATUS_SUBSCRIBED) {
            // Send Email to Admin
            try {
                $this->inlineTranslation->suspend();
                $store = $this->storeManager->getStore();
                $transport = $this->transportBuilder
                    ->setTemplateIdentifier('admin_new_subscription_template') // Email template
                    ->setTemplateOptions(['area' => 'frontend', 'store' => $store->getId()])
                    ->setTemplateVars(['subscriber' => $subscriber])
                    ->setFrom('general') // Email sender
                    ->addTo('s.rahman@absolute.digital') // Admin email
                    ->getTransport();

                $transport->sendMessage();
                $this->inlineTranslation->resume();
            } catch (\Exception $e) {
                // Handle the error
            }
        }
    }
}
