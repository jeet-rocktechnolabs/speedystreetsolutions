---
name: Feature
about: Internal Feature Request
title: ''
labels: 'feature, open'
assignees: ''

---

**Describe the feature**
A clear and concise description of what the feature is.

**Backend changes**
A clear and concise description of the new feature in the backend.

**Frontend changes**
A clear and concise description of the new feature in the frontend.

**Additional context**
Add any other context or screenshots about the feature request here.
