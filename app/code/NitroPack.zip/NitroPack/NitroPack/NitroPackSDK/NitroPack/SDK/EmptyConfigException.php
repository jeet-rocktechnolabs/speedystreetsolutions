<?php
namespace NitroPack\SDK;

class EmptyConfigException extends \RuntimeException {}
