<?php
namespace NitroPack\SDK\Integrations;

class Nginx extends ReverseProxy {}
